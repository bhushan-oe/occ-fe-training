# oeHeroBannerVictorLarini Widget

### Table of contents
- [oeHeroBannerVictorLarini Widget](#oeHeroBannerVictorLarini-widget)
    - [Description](#description)
    - [Installation](#installation)
    - [Installation and Configuration](#installation-and-configuration)
        - [Configs](#configs)
    - [Libraries](#libraries)
    - [Apis](#apis)
    - [OCC Version](#occ-version)
    - [Projects using this widget](#projects-using-this-widget)
    - [Screen Shots](#screen-shots)
    - [Development](#development)
    - [Todos](#todos)

### Description

The Widget Description

### Installation and configuration

The widget installation description

####Configs

Explain here what configurations exist and why they are there

### Libraries

My Widget uses:

* [KnockoutJS] - Javascript UI
* [jQuery] - DOM Manipulation, Ajax requests..

### Apis

All necessary Apis used from OCC Apis

* Name of api - Explanation

### OCC Version

version of occ which this widget has been built

### Projects using this widget

* [Name of Project](Dev or Production url) 

Please, update this document adding your project here in order to keep this tidy and trackable. 

### Screen Shots

URL of screen shots from this widget running. Save all screen shots on Google Drive and put the URLS here

### Development

Instructions for people who will maintain your code or fix something

* Follow the OE OCC Patterns
* Test your code before pushing to occ-components

### Todos

All todos

 - Write Tests
